<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width,initial-scale=1" name="viewport">
  <title>Welcome to Sona Aviations</title>
  <?php include '_header.php';?>
  <style type="text/css">
    #hero .container {
      padding-top: 0 !important;
      padding-bottom: 0 !important
    }

    @media (max-width:991px) {
      #hero .container {
        padding-top: 100px !important;
        padding-bottom: 100px !important
      }
    }
  </style>
</head>

<body>
  <?php include '_menu.php';?>
  <section class="home-banner-section py-0">
    <div class="home-banner-slider">
      <div class="banner-item">
        <div class="banner-content">
          <div class="author-content">
            <figure class="banner-img"><img src="assets/img/bg3.jpg" alt="" loading="lazy"></figure>
          </div>
        </div>
      </div>
      <div class="banner-item">
        <div class="banner-content">
          <div class="author-content">
            <figure class="banner-img"><img src="assets/img/bg4.jpg" alt="" loading="lazy"></figure>
          </div>
        </div>
      </div>
      <div class="banner-item">
        <div class="banner-content">
          <div class="author-content">
            <figure class="banner-img"><img src="assets/img/bg5.jpg" alt="" loading="lazy"></figure>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id="about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-title">
            <h2>About Us</h2><span class="animate-border mr-auto ml-auto mb-10"></span>
          </div>
        </div>
      </div>
      <div class="row align-items-center">
        <div class="col-lg-7 order-1 order-lg-1">
          <div class="side_content_about">
            <p>Sona Aviations Pvt Ltd is an Indian-based company that provides various aviation-related services. The
              company was established in 2017 and is headquartered in Greater Nodia West, GB Nagar, India.</p>
            <p>Sona Aviations offers a range of services, including aircraft chartering, Pilgrim charger services, Hele
              Resot, ground handling, and aviation consulting. The company provides charter services for private jets,
              helicopters, and cargo aircraft. It also offers aircraft management services, which include aircraft
              maintenance, crew management, and operational support.</p>
            <p>Sona Aviations has a team of experienced aviation professionals who are dedicated to providing
              high-quality services to their clients. The company has a strong focus on safety and compliance and has
              been certified by various regulatory authorities.</p>
            <p>Overall, Sona Aviations is a well-established company in the Indian aviation industry, providing a wide
              range of services to its clients.</p><button type="button" class="btn btn-primary" data-bs-toggle="modal"
              data-bs-target="#exampleModal">Enquiry Now</button>
          </div>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 hero-img">
          <div class="top-form">
            <div class="form-title">
              <h2>Hi 👋, Plan Your Char/Do Dham Yatra Packages</h2>
            </div>
            <div class="side_form">
              <form action="functions.php" method="POST">
                <div class="form-group"><input type="text" class="form-control" name="name" placeholder="Enter Name"
                    required></div>
                <div class="form-group"><input type="tel" class="form-control" name="contact"
                    oninput='this.value=this.value.replace(/[^0-9.]/g,"").replace(/(\..*)\./g,"$1")'
                    pattern="[1-9]{1}[0-9]{9}" maxlength="10" placeholder="Enter Phone" required></div>
                <div class="form-group"><input type="email" class="form-control" name="email" placeholder="Enter email"
                    required></div>
                <div class="row">
                  <div class="form-group col-lg-6"><select name="package" class="form-control" required>
                      <option value="" disabled="disabled" selected="selected">Select Package</option>
                      <option value="Char Dham 5N/6D -Rs.1.90 lac/pax">Char Dham 5N/6D -Rs.1.90 lac/pax</option>
                      <option value="Do Dham 3N/4D-Rs. 1.30 lac/ pax">Do Dham 3N/4D-Rs. 1.30 lac/ pax</option>
                      <option value="Do Dham 2N/3D Rs. 1.25 lac/ Pax">Do Dham 2N/3D Rs. 1.25 lac/ Pax</option>
                      <option value="Do Dham 1N/2D- Rs. 1.15 lac/ Pax">Do Dham 1N/2D- Rs. 1.15 lac/ Pax</option>
                      <option value="Ek Dham 1N/2D- Rs. 30 k/ Pax">Ek Dham 1N/2D- Rs. 30 K/ Pax</option>
                      <option value="Ek Dham 2N/3D- Rs. 7 k/ Pax">Ek Dham 2N/3D- Rs. 7 K/ Pax</option>
                      <option value="Do Dham 5N/6D- Rs. 16.5 k/ Pax">Do Dham 5N/6D- Rs. 16.5 k/ Pax</option>
                      <option value="Heli Resort">Heli Resort</option>
                      <option value="Air Taxi">Air Taxi</option>
                    </select></div>
                  <div class="form-group col-lg-6"><input type="number" class="form-control"
                      placeholder="No Of Travellers" value="" name="noPerson" min="1" required></div>
                </div>
                <div class="form-group"><textarea class="form-control" row="3" placeholder="Write Comments"
                    name="massage" required></textarea></div>
                <div class="form-group d-flex mt-2 align-items-center">
                  <div class="form-group col-auto"><input type="checkbox" name="myCheck" required></div>
                  <div class="form-group col">
                    <h6 class="card-title">I authorize Sona Aviations to contact me<a href="privacy-policy"
                        target="_blank">Privacy Policy</a></h6>
                  </div>
                </div><button type="submit" id="sendEnquiry" name="send_message_btn" class="btn btn-primary sendEnquiry"
                  style="width:100%">Send Enquiry</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <main id="main">
    <section class="home-package pt-0">
      <div class="container">
        <div class="section-heading">
          <h2 class="blog-title">We Offer Best Char Dham packages</h2>
          <p>We can customize your trip based on your needs and budgets. Just get in touch with us and leave the rest to
            us.</p>
        </div>
        <div class="package-section package-slider">
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg1.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Chardham Yatra By Helicopter Ex. Dehradun</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">5 Nights / 6 Days</span></div>
            </div>
          </div>
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg3.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Dodham Yatra By Helicopter Ex. Dehradun</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">3 Nights / 4 Days</span></div>
            </div>
          </div>
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg2.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Dodham Yatra By Helicopter Ex. Dehradun</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">2 Nights / 3 Days</span></div>
            </div>
          </div>
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg4.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Dodham Yatra By Helicopter Ex. Dehradun</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">1 Nights / 2 Days</span></div>
            </div>
          </div>
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg7.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Ek Dham By Helicopter Ex Sirsi</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">1 Nights / 2 Days</span></div>
            </div>
          </div>
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg5.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Ek Dham By Road Ex Haridwar</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">2 Nights / 3 Days</span></div>
            </div>
          </div>
          <div class="package-item">
            <div class="package-content">
              <figure class="package-img"><img src="assets/img/pkgs/pkg6.jpg" alt="" loading="lazy"></figure><a
                href="Packages">
                <h3 class="card-title">Do Dham By Road Ex Haridwar, Kedaranth & Badrinath</h3>
              </a>
              <div class="pkg-dur"><i class="bi bi-clock text-white"></i>&nbsp;&nbsp;<span
                  class="icon-text text-white">5 Nights / 6 Days</span></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="home-resort pt-0">
      <div class="container">
        <div class="section-heading">
          <h2 class="blog-title">We Offer Heli Resorts</h2>
          <p>Experience innovative Heli Resorts with exclusive accommodations, gourmet dining, and a range of amenities.
          </p>
        </div>
        <div class="resort-section resort-slider">
          <div class="resort-item">
            <div class="resort-content"><a href="heli-resort">
                <figure class="resort-img"><img src="assets/img/services/dest-4.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="resort-item">
            <div class="resort-content"><a href="heli-resort">
                <figure class="resort-img"><img src="assets/img/services/dest-8.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="resort-item">
            <div class="resort-content"><a href="heli-resort">
                <figure class="resort-img"><img src="assets/img/services/dest-9.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="resort-item">
            <div class="resort-content"><a href="heli-resort">
                <figure class="resort-img"><img src="assets/img/services/dest-10.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="resort-item">
            <div class="resort-content"><a href="heli-resort">
                <figure class="resort-img"><img src="assets/img/services/dest-11.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="resort-item">
            <div class="resort-content"><a href="heli-resort">
                <figure class="resort-img"><img src="assets/img/services/dest-12.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
        </div>
      </div>
    </section>
    <section class="home-air-taxi pt-0">
      <div class="container">
        <div class="section-heading">
          <h2 class="blog-title">We Offer Air Taxi Services</h2>
          <p>Experience convenience and comfort with our air taxi service.</p>
        </div>
        <div class="air-taxi-section air-taxi-slider">
          <div class="air-taxi-item">
            <div class="air-taxi-content"><a href="air-taxi">
                <figure class="air-taxi-img"><img src="assets/img/services/dest-2.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="air-taxi-item">
            <div class="air-taxi-content"><a href="air-taxi">
                <figure class="air-taxi-img"><img src="assets/img/services/dest-3.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
          <div class="air-taxi-item">
            <div class="air-taxi-content"><a href="air-taxi">
                <figure class="air-taxi-img"><img src="assets/img/services/dest-5.webp" alt="" loading="lazy"></figure>
              </a></div>
          </div>
        </div>
      </div>
    </section>
    <section class="bg_image_section" style="background-image:url(assets/img/planbg.jpg)">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <div class="center-texts" style="background:#00000082;padding:15px">
              <h2 style="font-family:Montserrat,sans-serif">Customize Your Trip</h2>
              <p>We can customize your trip based on your needs and budgets. Just get in touch with us and leave the
                rest to us.</p><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                data-bs-target="#exampleModal" style="margin-top:30px">PLAN MY TRIP</button>
            </div>
          </div>
          <div class="col-md-6">
            <div class="center-image"><a href="javascript:void(0)" data-bs-toggle="modal"
                data-bs-target="#exampleModal"><img src="assets/img/plan.jpg" loading="lazy"></a></div>
          </div>
        </div>
      </div>
    </section>
    <section id="testimonial" class="home-testimonial">
      <div class="container">
        <div class="section-title">
          <h2>Our Travelers Review</h2><span class="animate-border mr-auto ml-auto mb-10"></span>
          <p>Thoughts from our clients</p>
        </div>
        <div class="testimonial-section testimonial-slider">
          <div class="testimonial-item">
            <div class="testimonial-content">
              <div class="author-content">
                <figure class="testimonial-img"><img src="assets/img/reviewer/user-img2.png" alt=""></figure>
                <div class="author-name">
                  <h5>Kumar Vaibhav</h5><span>TRAVELLERS</span>
                </div>
              </div>
              <div class="rating-start-wrap">
                <div class="rating-start"><span style="width:100%"></span></div>
              </div>
              <p class="testi_content">The whole package is prepared in such a way that you would never feel that you
                are not taken care at any time. Every step of your journey you will be accompanied and informed. The
                best chardham tours you can opt for.</p>
              <div class="testimonial-icon"><i aria-hidden="true" class="fas fa-quote-left"></i></div>
            </div>
          </div>
          <div class="testimonial-item">
            <div class="testimonial-content">
              <div class="author-content">
                <figure class="testimonial-img"><img src="assets/img/reviewer/user-img1.png" alt=""></figure>
                <div class="author-name">
                  <h5>Jyotsna Aerra</h5><span>TRAVELLERS</span>
                </div>
              </div>
              <div class="rating-start-wrap">
                <div class="rating-start"><span style="width:100%"></span></div>
              </div>
              <p class="testi_content">Awesome service by Sona Aviation..i salute them ...i took package for Do dham...
                kedarnath n badrinath in one ....they have done a great job i did both darshan in one that to very
                quickly...kind gesture by coordinating team ....and Aviation team ...and guide .....and hotel management
                team.... everyone is very cooperative...and speaks up very friendly and explain each n everything very
                clearly...i love to travel with them again for gangotri n yamunotri... Thank you so much for
                everything...as my dream came true..</p>
              <div class="testimonial-icon"><i aria-hidden="true" class="fas fa-quote-left"></i></div>
            </div>
          </div>
          <div class="testimonial-item">
            <div class="testimonial-content">
              <div class="author-content">
                <figure class="testimonial-img"><img src="assets/img/reviewer/user-img1.png" alt=""></figure>
                <div class="author-name">
                  <h5>sanjay gupta</h5><span>TRAVELLERS</span>
                </div>
              </div>
              <div class="rating-start-wrap">
                <div class="rating-start"><span style="width:100%"></span></div>
              </div>
              <p class="testi_content">They coordination is very good and helpful, and good arrangements.</p>
              <div class="testimonial-icon"><i aria-hidden="true" class="fas fa-quote-left"></i></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include '_footer.php'; ?>
  <script type="text/javascript" src="assets/js/jquery.js"></script>
  <script>
    //   $(document).on('click', '#sendEnquiry', function(){
    //     alert('ranjeet'); 
    //  }
    $("form").submit(function () {
      //alert('ranjeet');
      $(this).find('button[type="submit"]').prop("disabled", true);
    });
  </script>
</body>

</html>