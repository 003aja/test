<?php

if(!empty($_POST))
{
foreach($_POST as $key=>$val)
{
$arr[]= $key.": ".$val."      " ;

}

//27-01-2023
$um_id="0";
// $handle = fopen("counter.txt", "r"); 
// if(!$handle){
// echo "Could not open the file" ;
// }
// else {
// $counter = ( int ) fread ($handle,2) ;
// fclose ($handle) ;
// $counter++ ; 
// if($counter == 2){
//     $um_id=3;
// $counter=0;
// }
// if($counter == 1)
//     $um_id=2;

// //echo" <p> Visitor Count: ". $counter . " </p> " ; 
// $handle = fopen("counter.txt", "w" ) ; 
// fwrite($handle,$counter) ; 
// fclose ($handle) ;
// }






$str=implode('',$arr);
require_once('config.php');
$link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$ceEmails=$_POST['email'];
$stmt = $dbh->prepare("SELECT CE_ID from CUSTMOR_ENQUIRY where CE_EMAIL='$ceEmails'");
$stmt->execute(); 
$ceIdsst = $stmt->fetch();
//echo $ceIdsst[0];
if($ceIdsst[0] !=''){
    	try
{
	$sql123 = "UPDATE CUSTMOR_ENQUIRY SET ce_date=sysdate(), ce_number=?  WHERE ce_id=?";
$stmt123= $dbh->prepare($sql123);
$stmt123->execute([$_POST['contact'],  $ceIdsst[0] ]);
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
}
// $stmt = $dbh->prepare("SELECT CE_ID FROM CUSTMOR_ENQUIRY WHERE CE_EMAIL=".$_POST['email']);
// $stmt->execute(); 
// $ce_ids = $stmt->fetch(PDO::FETCH_ASSOC);
//echo $ce_ids;
//console.log("ranjeet gupta");
//console.log($ce_ids);
//DATABASE INSERTION
$package=$_POST['package'];
try{
$sql="INSERT  INTO CUSTMOR_ENQUIRY(CE_NAME, CE_NUMBER, CE_EMAIL, CE_NO_PERSON, CE_CUSTMOR_MSG, CE_DATE, CE_FLAG, CE_PACKAGE, CE_COUNTRY_FLAG, CE_URL, CE_EMP_ID, CE_STATUS, CE_SITESTATUS) VALUES(:CE_NAME, :CE_NUMBER, :CE_EMAIL, :CE_NO_PERSON, :CE_CUSTMOR_MSG, sysdate(), 'E', :CE_PACKAGE, 'SI', :CE_URL, :CE_EMP_ID, 'Open', 'P')";
$query = $dbh->prepare($sql);
$query->bindParam(':CE_NAME',$_POST['name'],PDO::PARAM_STR);
$query->bindParam(':CE_NUMBER',$_POST['contact'],PDO::PARAM_STR);
$query->bindParam(':CE_EMAIL',$_POST['email'],PDO::PARAM_STR);
$query->bindParam(':CE_NO_PERSON',$_POST['noPerson'],PDO::PARAM_STR);
$query->bindParam(':CE_CUSTMOR_MSG',$_POST['massage'],PDO::PARAM_STR);
$query->bindParam(':CE_PACKAGE',$_POST['package'],PDO::PARAM_STR);

$query->bindParam(':CE_URL',$link,PDO::PARAM_STR);
$query->bindParam(':CE_EMP_ID',$um_id,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
}
catch (PDOException $e)
{
//exit("Error: " . $e->getMessage());
}



//echo $str;
$to="info@sonaaviations.com";
$subject="Query On Sona Aviations";
$msg=$str;
$headers="Website Query";
//$header="Bcc: digioptimise@gmail.com \r\n";
//$header="Bcc: ranjeetgupta97@gmail.com \r\n";\
$header="";

$mobile23=$_POST['contact'];
$newmbl="";
$mobile=substr($mobile23,strlen($mobile23)-10,strlen($mobile23));
$newmbl="91".$mobile;
$whatsappmsg = 'Dear Sir/Madam,

Thanks for showing your interest in Char Dham / DO Dham / Ek Dham Yatra by Helicopter with Sona Aviations on Google.

Request you to please share the following details to get the quotation:

1. Name Of Passenger
2. Passenger Age
3. Passenger Body Weight
4. Travel Date
5. Yatra Type(Char/Do/Ek Dham)

You can call us for booking at the following numbers:
8287957737, 8595819286, 7011548789, 0120-4280292
Email: info@sonaaviations.com

Looking forward to hearing from you.

Thanks & Regards
Alok Gupta
Managing Director- Sona Aviations';
$message=urlencode($whatsappmsg);
//$mes22=urlencode("CharDham Yatra by Helicopter (Yamunotri, Gangotri, Kedarnath //& Badrinath). Bookings Open Now. Customized packages available.");
$mes22="";
$mshh='ðŸ‘‡Select an optionðŸ‘‡
        9999661157
https://www.youtube.com/channel/UCyaXfOMk95MGrVOmHpWY4UQ';
$mes222=urlencode($mshh);
// $url9='https://wasoft.wappblaster.com/api/send.php?number=91'.$mobile.'&type=text&message='.$mes222.'&instance_id=62AC972BAF24B&access_token=69dcdde6a36a38d39d105e7e9b421771';

// $url2='http://api.bulkwhatsapp.net/wapp/api/send?apikey=52892f3fae7d4611a67918266e0280aa&mobile='.$mobile.'&msg=&pdf=https://chardhamyatrapacks.co.in/files/DO_DHAM_SAPL_2N_3D.pdf';
// $url='https://wasoft.wappblaster.com/api/send.php?number=91'.$mobile.'&type=media&message='.$mes22.'&media_url=https://chardhamyatrapacks.co.in/files/chardham.jpeg&filename=chardham.jpeg&instance_id=62AC972BAF24B&access_token=69dcdde6a36a38d39d105e7e9b421771';


// $ch = curl_init();
 
//   // Set the file URL to fetch through cURL
//   curl_setopt($ch, CURLOPT_URL, $url);
 
//   // Do not check the SSL certificates
//   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
//   // Return the actual result of the curl result instead of success code
//   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//   curl_setopt($ch, CURLOPT_HEADER, 0);
//   $data = curl_exec($ch);
//   curl_close($ch);
 
 
//   $urlnew = "http://139.59.92.57/send-media";

// $curl = curl_init($urlnew);
// curl_setopt($curl, CURLOPT_URL, $urlnew);
// curl_setopt($curl, CURLOPT_POST, true);
// curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// $headersnew = array(
//   "Content-Type: application/json",
// );
// curl_setopt($curl, CURLOPT_HTTPHEADER, $headersnew);

// $datanew = '{"number":"91'.$mobile.'","caption":"","file":"https://chardhamyatrapacks.co.in/files/chardham.jpeg"}';

// curl_setopt($curl, CURLOPT_POSTFIELDS, $datanew);

// //for debug only!
// curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
// curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

// $resp = curl_exec($curl);
// curl_close($curl);





//var_dump($resp);
 
 
// $urlnewmess = "http://139.59.82.77:3333/message/text?key=0a00c51e-448e-4bbc-9e71-6b00e5081b50";

// $curlmess = curl_init($urlnewmess);
// curl_setopt($curlmess, CURLOPT_URL, $urlnewmess);
// curl_setopt($curlmess, CURLOPT_POST, true);
// curl_setopt($curlmess, CURLOPT_RETURNTRANSFER, true);

// $headersmess = array(
//   "Content-Type: application/json",
// );
// curl_setopt($curlmess, CURLOPT_HTTPHEADER, $headersmess);

// //$datamess = '{"number":"91'.$mobile.'","message":"'.$mshh.'"}';
// $datamess = '{"id":"91'.$mobile.'","message":"ðŸ‘‡Select an optionðŸ‘‡\n        9999661157\nhttps://www.youtube.com/channel/UCyaXfOMk95MGrVOmHpWY4UQ"}';
// curl_setopt($curlmess, CURLOPT_POSTFIELDS, $datamess);

// //for debug only!
// curl_setopt($curlmess, CURLOPT_SSL_VERIFYHOST, false);
// curl_setopt($curlmess, CURLOPT_SSL_VERIFYPEER, false);

// $respmess = curl_exec($curlmess);
// curl_close($curlmess);



//var_dump($respmess);
 
//   $ch2 = curl_init();
 
//   // Set the file URL to fetch through cURL
//   curl_setopt($ch2, CURLOPT_URL, $url9);
 
//   // Do not check the SSL certificates
//   curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
 
//   // Return the actual result of the curl result instead of success code
//   curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
//   curl_setopt($ch2, CURLOPT_HEADER, 0);
//   $data2 = curl_exec($ch2);
//   curl_close($ch2);
 
// $ch1 = curl_init();
// curl_setopt($ch1, CURLOPT_URL, $url2);
// curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
// $output1 = curl_exec($ch1);
// //echo $output;
// curl_close($ch1);

//new code 2023

// $curl = curl_init();

// curl_setopt_array($curl, [
//   CURLOPT_PORT => "3333",
//   CURLOPT_URL => "http://34.131.54.208:3333/message/text?key=b484d0f1-cbc9-4721-87f1-e106444e9c29",
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => "",
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 30,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => "POST",
//   CURLOPT_POSTFIELDS => "id=919716312860&message=Test",
//   CURLOPT_HTTPHEADER => [
//     "Accept: */*",
//     "Content-Type: application/x-www-form-urlencoded",
//     "User-Agent: Thunder Client (https://www.thunderclient.com)"
//   ],
// ]);

// $response = curl_exec($curl);
// $err = curl_error($curl);

// curl_close($curl);

// if ($err) {
//   echo "cURL Error #:" . $err;
// } else {
//   echo $response;
// }



//start
// $curl = curl_init();

// curl_setopt_array($curl, [
//   CURLOPT_URL => "http://34.131.5.59/message/MediaButton?key=79197473-1f42-4b88-b254-865c780de1ed",
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => "",
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 30,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => "POST",
//   CURLOPT_POSTFIELDS => "{\n    \"id\": \"$newmbl\",\n    \"btndata\": {\n        \"text\": \"🚁 Char Dham By Helicopter\",\n        \"buttons\": [\n           \n            {\n                \"type\": \"callButton\",\n                \"title\": \"Call Us\",\n                \"payload\": \"918291182993\"\n            },\n             {\n                \"type\": \"urlButton\",\n                \"title\": \"Video Itinerary\",\n                \"payload\": \"https://www.youtube.com/watch?v=9UMNMAXTMrw\"\n            },\n            {\n                \"type\": \"urlButton\",\n                \"title\": \"Price Detail\",\n                \"payload\": \"https://chardhamyatrapacks.co.in/files/Char_Dham_Price_detail.pdf\"\n            }\n        ],\n        \"footerText\": \"Book Now\",\n        \"image\": \"https://chardhamyatrapacks.co.in/files/char-dham.jpeg\",\n        \"mediaType\": \"image\",\n        \"mimeType\": \"image/jpeg\"\n    }\n}",
//   CURLOPT_HTTPHEADER => [
//     "Accept: */*",
//     "Content-Type: application/json",
//   //"User-Agent: Thunder Client (https://www.thunderclient.com)"
//   ],
// ]);

// $response = curl_exec($curl);
// $err = curl_error($curl);

// curl_close($curl);

// if ($err) {
//   echo "cURL Error #:" . $err;
// } else {
//   //echo $response;
// }
//end

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://35.172.186.234/message/mediaurl?key=0294a3d6-f294-4315-9538-165df30753a9",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "id=$newmbl&url=https%3A%2F%2Fsonaaviations.com%2Ffiles%2Fnewchardham.jpeg&type=image&mimetype=image%2Fjpeg&caption=Call%20Us%3A%208291182993%0A",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded",
    "postman-token: 003655bf-6f24-774e-091b-869ca66e2a64"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}

if(mail($to,$subject,$msg,$header))
{
   
$wemail_subject="Char Dham/ Do Dham / Ek Dham Yatra By helicopter";
$wemail_body="<html><head></head><body><div >Dear Sir/Madam,<br><br>Thanks for showing your interest in Char Dham / DO Dham / Ek Dham Yatra by Helicopter with Sona Aviations on Google.<br><br>Here is our itinerary for the Char Dham Yatr. Request you to please share the following details to get the quotation:<br><br>1. Name Of Passenger<br>2. Passenger Age<br>3. Passenger Body Weight<br>4. Travel Date<br><br>You can call us for booking at the following numbers:<br>8287957737, 8595819286, 7011548789, 0120-4280292<br>Email: <a href='mailto:info@sonaaviations.com'>info@sonaaviations.com</a><br><br>Looking forward to hearing from you.<br><img src='https://sonaaviations.com/files/chardham.jpeg' width='70%' height='40%'><br><br>Thanks &amp; Regards<br>Alok Gupta<br>Managing Director- Sona Aviations<br></div></body></html>";
$wemail_from = "info@sonaaviations.com";//<== update the email address
$files = array(
    'files/Char_Dham_4N_5D_SAPL.pdf'
);
//$file = "files/Char_Dham_4N_5D_SAPL.pdf";
$fromName = 'Sona Aviations';

$wto=trim($_POST['email']);
//$wheaders = "From: $wemail_from \r\n";
//$headers = "Bcc: ruchita.kishu@gmail.com \r\n";
//$wheaders = "";

         
//$wheaders .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
//$wheaders= 'From: '.$fromName.'<'.$to.'>' . 'Reply-To: <.$to.>';
   
$semi_rand = md5(time());  
$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
 $wheaders = "MIME-Version: 1.0\r\n"; // Defining the MIME version
    $wheaders .= "From:".$to."\r\n"; // Sender Email
    $wheaders .= "Reply-To: ".$to."\r\n";
    $wheaders .= "Content-Type: multipart/mixed;"; // Defining Content-Type
    $wheaders .= "boundary = $mime_boundary\r\n"; //Defining the Boundary
// Headers for attachment  
//$wheaders .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " //boundary=\"{$mime_boundary}\"";
$wmessage = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
"Content-Transfer-Encoding: 8bit\n\n" . $wemail_body . "\n\n";  
if(!empty($files)){
        for($i=0;$i<count($files);$i++){
            if(is_file($files[$i])){
                $file_name = basename($files[$i]);
                $file_size = filesize($files[$i]);
                 
                $wmessage .= "--{$mime_boundary}\n";
                $fp =    @fopen($files[$i], "rb");
                $data =  @fread($fp, $file_size);
                @fclose($fp);
                $data = chunk_split(base64_encode($data));
                $wmessage .= "Content-Type: application/octet-stream; name=\"".$file_name."\"\n" .  
                "Content-Description: ".$file_name."\n" .
                "Content-Disposition: attachment;\n" . " filename=\"".$file_name."\"; size=".$file_size.";\n" .  
                "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
            }
        }
    }


// if(!empty($file) > 0){
//     if(is_file($file)){
//         $wmessage .= "--{$mime_boundary}\n";
//         $fp =    @fopen($file,"rb");
//         $data =  @fread($fp,filesize($file));
 
//         @fclose($fp);
//         $data = chunk_split(base64_encode($data));
//         $wmessage .= "Content-Type: application/octet-stream; name=\"".basename($file)."\"\n"."Content-Description: ".basename($file)."\n"."Content-Disposition: attachment;\n" . " filename=\"".basename($file)."\"; size=".filesize($file).";\n" ."Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
//     }
// }
$wmessage .= "--{$mime_boundary}--";
$returnpath = "-f" . $to;
mail($wto,$wemail_subject,$wmessage,$wheaders);
//send whats app message


echo $str."<script type='text/javascript'>window.location='thankyou.html';</script>";
}
else
{
echo "<script type='text/javascript'>alert('oops! Error occured.'); window.location='thankyouerror.html';</script>";

}


}


?>