<?php
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','sonaavia_ranjeet');
define('DB_PASS','Ranjee@2040');
define('DB_NAME','sonaavia_hotel'); // put you database name here
define( 'DB_CHARSET', 'utf8mb4' );
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>