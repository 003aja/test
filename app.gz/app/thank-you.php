<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta content="width=device-width,initial-scale=1" name="viewport"><title>Thank You | Chardham and Do Dham Tour Packages | Sona Aviations</title> <?php include '_header.php';?> <style>@media (max-width:767px){#hero{margin-top:0}}#hero .container{padding-top:0}.img-fluid{max-width:100%;height:auto;background:#fff;border-radius:10px}</style>
<!-- Event snippet for enquiry track conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-11079631988/9Y_tCJqM8okYEPSIl6Mp',
      'value': 1.0,
      'currency': 'INR'
  });
</script>
</head><body> <?php include '_menu.php';?> <section id="hero" class="d-flex align-items-center" style="background-image:url(assets/img/planbg.jpg);height:100vh;background-size:cover"><div class="container thank_you"><div class="row text-center justify-content-center"><div class="overlay"><div class="col-md-12 d-flex flex-column justify-content-center"><a href="./" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a><h1>THANKS FOR SUBMITTING !</h1><h2>Your query has been sent to us. We will get back to you soon.</h2><div><a href="./" class="btn-get-started scrollto" style="background-color:var(--c-primary)">Homepage</a></div></div></div></div></div></section> <?php include '_footer.php';?> </body></html>