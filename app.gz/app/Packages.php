<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width,initial-scale=1" name="viewport">
  <title>Chardham and Do Dham Tour Packages | Sona Aviations</title>
  <?php include '_header.php';?>
  <style type="text/css">
    #hero .container {
      padding-top: 0 !important;
      padding-bottom: 0 !important
    }

    section {
      overflow: unset
    }

    @media (max-width:991px) {
      #hero .container {
        padding-top: 100px !important;
        padding-bottom: 100px !important
      }
    }
  </style>
</head>

<body>
  <?php include '_menu.php';?>
  <section class="page-header">
    <div class="page-header__top">
      <div class="page-header-bg" style="background-image:url(assets/img/bg3.jpg)"></div>
      <div class="container">
        <div class="page-header__top-inner"></div>
      </div>
    </div>
    <div class="page-header__bottom">
      <div class="container">
        <div class="page-header__bottom-inner">
          <ul class="thm-breadcrumb list-unstyled">
            <li><a href="./">Home</a></li>
            <li><span>.</span></li>
            <li class="active">Char Dham Package</li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <main id="main">
    <section style="background-image:url(assets/img/white-bg.png)">
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="row">
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg1.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 1,90,000 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Chardham Yatra By Helicopter Ex. Dehradun</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span class="icon-text text-muted">Day1-
                        Dehradun | Day2- Yamunotri | Day3- Gangotri | Day4- Kedarnath | Day5- Badrinath | Day6-
                        Dehradun</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">5 Nights / 6
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/binocular.png" alt="Hotel" title="Hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Sightseeing</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Complimentary Night stay With Breakfast & Dinner at Dehradun.
                          </h6>
                        </div>
                        <div class="moretext1">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Pick up and drop from Dehradun Airport/ Railway Station/ Bus
                              Stand.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Special VIP Darshan at All Dhams.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Premium Resort Stay, Breakfast, Lunch, Dinner & Sight seen in
                              all Dhams.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Complimentary duffle bag.
                            </h6>
                          </div>
                        </div>
                      </div><a class="moreless-button1" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg3.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 1,30,000 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Dodham Yatra By Helicopter Ex. Dehradun</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span class="icon-text text-muted">:
                        Day1-Dehradun| Day2-Kedarnath | Day3-Badrinth | Day4-Dehradun</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">3 Nights / 4
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/binocular.png" alt="Hotel" title="Hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Sightseeing</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Complimentary Night stay With Breakfast & Dinner at Dehradun.
                          </h6>
                        </div>
                        <div class="moretext2">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Pick up and drop from Dehradun Airport/ Railway Station/ Bus
                              Stand.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Special VIP Darshan at All Dhams.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Stay, Breakfast, Lunch, Dinner & Sightseeing in all Dhams.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Complimentary duffle bag.
                            </h6>
                          </div>
                        </div>
                      </div><a class="moreless-button2" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg2.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 1,25,000 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Dodham Yatra By Helicopter Ex. Dehradun</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span
                        class="icon-text text-muted">Day1-Dehradun| Day2-Kedarnath - Badrinth | Day3-Dehradun</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">2 Nights / 3
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/binocular.png" alt="Hotel" title="Hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Sightseeing</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Complimentary Night stay With Breakfast & Dinner at Dehradun.
                          </h6>
                        </div>
                        <div class="moretext3">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Pick up and drop from Dehradun Airport/ Railway Station/ Bus
                              stand
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Special VIP Darshan at All Dhams.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Premium Resort Stay in Kedaranth or Badrinath. Breakfast,
                              Lunch, Dinner & Sight seen.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Complimentary duffle bag.
                            </h6>
                          </div>
                        </div>
                      </div><a class="moreless-button3" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg4.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 1,15,000 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Dodham Yatra By Helicopter Ex. Dehradun</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span class="icon-text text-muted">Day 1
                        Dehradun | Day 2 Kedarnath - Badrinath | Day 2 Dehradun</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">1 Nights / 2
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Complimentary Night stay With Breakfast & Dinner at Dehradun.
                          </h6>
                        </div>
                        <div class="moretext4">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Pick up and drop from Dehradun Airport/ Railway Station/ Bus
                              stand.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Special VIP Darshan at All Dhams & Lunch at Badrinath.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Complimentary duffle bag.
                            </h6>
                          </div>
                        </div>
                      </div><a class="moreless-button4" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg7.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 30,000 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Ek Dham By Helicopter Ex Sirsi</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span class="icon-text text-muted">Day 1
                        Sirsi | Day 2 Kedarnath | Day 2 Sirsi</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">1 Nights / 2
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Hotel Night stay.
                          </h6>
                        </div>
                        <div class="moretext7">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Dinner Breakfast.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Helicopter/Pony/ Palki
                            </h6>
                          </div>
                          <p class="icon-title">Package Exclusion:</p>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Lunch.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Near Kedaranth Temple Night stay.
                            </h6>
                          </div>
                        </div>
                      </div><a class="moreless-button7" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg5.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 7,000 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Ek Dham By Road Ex Haridwar</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span class="icon-text text-muted">Day 1
                        Haridwar to Sirsi | Day 2 Kedarnath tracking | Day 3 Sirsi to Haridwar</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">2 Nights / 3
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Hotel Night stay at Sirsi and Kedarnath.
                          </h6>
                        </div>
                        <div class="moretext5">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Dinner Breakfast.
                            </h6>
                          </div>
                          <p class="icon-title">Package Exclusion:</p>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Lunch.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Helicopter/Pony/ Palki
                            </h6>
                          </div>
                          <p><span style="color:red">*</span>Valid Till 31 August 2023 after 31st August Rs. 9500/ per
                            pax</p>
                        </div>
                      </div><a class="moreless-button5" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card pkgs"><img class="card-img-top" src="assets/img/pkgs/pkg6.jpg" alt="Card image cap"
                    loading="lazy">
                  <div class="tag">₹ 16,500 /Per Pax</div>
                  <div class="card-body">
                    <h3 class="card-title">Do Dham By Road Ex Haridwar, Kedaranth & Badrinath</h3>
                    <p class="days_cal"><i class="bi bi-pin-map icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Package Starting:&nbsp;&nbsp;</span><span class="icon-text text-muted">Day 1
                        Haridwar to Sirsi | Day 2 Kedarnath tracking | Day 3 Sirsi | Day 4 Badrinath | Day 5 Rudraprayag
                        | Day 6 Haridwar</span></p>
                    <p class="days_cal"><i class="bi bi-clock icon-color"></i>&nbsp;&nbsp;<span
                        class="icon-title">Duration:&nbsp;&nbsp;</span><span class="icon-text text-muted">5 Nights / 6
                        Days</span></p>
                    <ul class="itnry d-flex">
                      <li class="active">
                        <figure><img src="assets/img/icons/hotel.png" alt="hotel" title="hotel" class="icon-image"
                            loading="lazy"></figure>
                        <p>Hotel</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/meal.png" alt="Meal" title="Meal" class="icon-image"
                            loading="lazy"></figure>
                        <p>Food</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/taxi.png" alt="Car" title="Car" class="icon-image"
                            loading="lazy"></figure>
                        <p>Transfers</p>
                      </li>
                      <li>
                        <figure><img src="assets/img/icons/terms-and-conditions.png" alt="Car" title="Car"
                            class="icon-image" loading="lazy"></figure>
                        <p>T & C</p>
                      </li>
                    </ul>
                    <div class="Inclusion-list">
                      <p class="icon-title">Package Inclusion:</p>
                      <div class="row">
                        <div class="col-12 mb-10">
                          <h6 class="Incl-lt-sb-t">
                            <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                loading="lazy"></figure>Hotel Night stay.
                          </h6>
                        </div>
                        <div class="moretext6">
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Dinner Breakfast.
                            </h6>
                          </div>
                          <p class="icon-title">Package Exclusion:</p>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Lunch.
                            </h6>
                          </div>
                          <div class="col-12 mb-10">
                            <h6 class="Incl-lt-sb-t">
                              <figure><img src="assets/img/icons/arrow.png" alt="arrow" title="arrow" class="icon-image"
                                  loading="lazy"></figure>Helicopter/Pony/ Palki
                            </h6>
                          </div>
                        </div>
                      </div><a class="moreless-button6" href="javascript:void(0)">Read more</a>
                    </div>
                    <div class="two_buttons"><button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal" style="margin:10px">Send Enquiry</button><a
                        href="tel:+918291182993" class="call btn btn-primary"><i class="fa fa-phone"></i>&nbsp;Call
                        Us</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 right-side">
            <div class="top-form">
              <div class="form-title">
                <h2>Hi 👋, Plan Your Char/Do Dham Yatra Packages</h2>
              </div>
              <div class="side_form">
                <form action="functions.php" method="POST">
                  <div class="form-group"><input type="text" class="form-control" name="name" placeholder="Enter Name"
                      required></div>
                  <div class="form-group"><input type="tel" class="form-control" name="contact"
                      oninput='this.value=this.value.replace(/[^0-9.]/g,"").replace(/(\..*)\./g,"$1")'
                      pattern="[1-9]{1}[0-9]{9}" maxlength="10" placeholder="Enter Phone" required></div>
                  <div class="form-group"><input type="email" class="form-control" name="email"
                      placeholder="Enter email" required></div>
                  <div class="row">
                    <div class="form-group col-lg-6"><select name="package" class="form-control" required>
                        <option value="" disabled="disabled" selected="selected">Select Package</option>
                        <option value="Char Dham 5N/6D -Rs.1.90 lac/pax">Char Dham 5N/6D -Rs.1.90 lac/pax</option>
                        <option value="Do Dham 3N/4D-Rs. 1.30 lac/ pax">Do Dham 3N/4D-Rs. 1.30 lac/ pax</option>
                        <option value="Do Dham 2N/3D Rs. 1.25 lac/ Pax">Do Dham 2N/3D Rs. 1.25 lac/ Pax</option>
                        <option value="Do Dham 1N/2D- Rs. 1.15 lac/ Pax">Do Dham 1N/2D- Rs. 1.15 lac/ Pax</option>
                        <option value="Ek Dham 1N/2D- Rs. 30 k/ Pax">Ek Dham 1N/2D- Rs. 30 K/ Pax</option>
                        <option value="Ek Dham 2N/3D- Rs. 7 k/ Pax">Ek Dham 2N/3D- Rs. 7 K/ Pax</option>
                        <option value="Do Dham 5N/6D- Rs. 16.5 k/ Pax">Do Dham 5N/6D- Rs. 16.5 k/ Pax</option>
                      </select></div>
                    <div class="form-group col-lg-6"><input type="number" class="form-control"
                        placeholder="No Of Travellers" value="" name="noPerson" min="1" required></div>
                  </div>
                  <div class="form-group"><textarea class="form-control" row="3" placeholder="Write Comments"
                      name="massage" required></textarea></div>
                  <div class="form-group d-flex mt-2 align-items-center">
                    <div class="form-group col-auto"><input type="checkbox" name="myCheck" required></div>
                    <div class="form-group col">
                      <h6 class="card-title">I authorize Sona Aviations to contact me<a href="./privacy-policy"
                          target="_blank">Privacy Policy</a></h6>
                    </div>
                  </div><button type="submit" id="sendEnquiry" name="send_message_btn"
                    class="btn btn-primary sendEnquiry" style="width:100%">Send Enquiry</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include '_footer.php'; ?>
  <script type="text/javascript" src="assets/js/jquery.js"></script>
  <script>
    //   $(document).on('click', '#sendEnquiry', function(){
    //     alert('ranjeet'); 
    //  }
    $("form").submit(function () {
      //alert('ranjeet');
      $(this).find('button[type="submit"]').prop("disabled", true);
    });
  </script>
</body>

</html>